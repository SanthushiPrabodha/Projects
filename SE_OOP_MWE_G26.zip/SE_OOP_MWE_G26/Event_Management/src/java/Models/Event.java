//Author     : Hemachandra M.G.S.P. IT19011844
package Models;


public class Event{

	private int eventId;
	private String eventName;
	private String eventTheme;
	private String packages;
	private String date;
	private String time;
	private String venue;

public Event(){
}

public Event(int eventId){
	this.eventId = eventId;
}
public Event(int eventId,String eventName,String eventTheme,String packages,String date,String time,String venue){
	this.eventId = eventId;
	this.eventName = eventName;
	this.eventTheme = eventTheme;
	this.packages = packages;
	this.date = date;
	this.time = time;
	this.venue = venue;
}

public int getEventId(){
return eventId;
}

public void setEventId(int eventId){
	this.eventId = eventId;
}

public String getEventName(){
return eventName;
}

public void setEventName(String eventName){
	this.eventName = eventName;
}

public String getEventTheme(){
return eventTheme;
}

public void setEventTheme(String eventTheme){
	this.eventTheme = eventTheme;
}

public String getPackages(){
return packages;
}

public void setPackages(String packages){
	this.packages = packages;
}

public String getDate(){
return date;
}

public void setDate(String date){
	this.date = date;
}

public String getTime(){
return time;
}

public void setTime(String time){
	this.time = time;
}

public String getVenue(){
return venue;
}

public void setVenue(String venue){
	this.venue = venue;
}

}