//Author     : Shehara P.G.J. IT19141770
package Models;


public class Service{

	private int service_id;
	private int event_id;
	private String service_type;
	private String date;
	private String duration;
	private String supplier_name;
	private String supplier_phone_no;
	private String supplier_email;

public Service(){
}

public Service(int service_id){
	this.service_id = service_id;
}
public Service(int service_id,int event_id,String service_type,String date,String duration,String supplier_name,String supplier_phone_no,String supplier_email){
	this.service_id = service_id;
	this.event_id = event_id;
	this.service_type = service_type;
	this.date = date;
	this.duration = duration;
	this.supplier_name = supplier_name;
	this.supplier_phone_no = supplier_phone_no;
	this.supplier_email = supplier_email;
}

public int getService_id(){
return service_id;
}

public void setService_id(int service_id){
	this.service_id = service_id;
}

public int getEvent_id(){
return event_id;
}

public void setEvent_id(int event_id){
	this.event_id = event_id;
}

public String getService_type(){
return service_type;
}

public void setService_type(String service_type){
	this.service_type = service_type;
}

public String getDate(){
return date;
}

public void setDate(String date){
	this.date = date;
}

public String getDuration(){
return duration;
}

public void setDuration(String duration){
	this.duration = duration;
}

public String getSupplier_name(){
return supplier_name;
}

public void setSupplier_name(String supplier_name){
	this.supplier_name = supplier_name;
}

public String getSupplier_phone_no(){
return supplier_phone_no;
}

public void setSupplier_phone_no(String supplier_phone_no){
	this.supplier_phone_no = supplier_phone_no;
}

public String getSupplier_email(){
return supplier_email;
}

public void setSupplier_email(String supplier_email){
	this.supplier_email = supplier_email;
}

}