//Author     : Panditha D.T. IT19227528
package Controllers;


import Models.User;
import DataBaseConnector.Connector;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class UserController{

	Connector con = Connector.getInstance();

	private UserController(){
	}

	private static final UserController obj = new UserController();

	public static UserController getInstance(){
		return obj;
	}

	public void Save(User data) throws Exception {
		con.getConnection();
		con.aud("INSERT INTO user(fullName,username,password,userType,date,email,phone) values ('" + data.getFullName()+ "','" + data.getUsername()+ "','" + data.getPassword()+ "','" + data.getUserType()+ "','" + data.getDate()+ "','" + data.getEmail()+ "','" + data.getPhone()+ "') " );
	}

	public void Update(User data) throws Exception {
		con.getConnection();
		con.aud("UPDATE user SET fullName  = '" + data.getFullName()+ "',username  = '" + data.getUsername()+ "',password  = '" + data.getPassword()+ "',userType  = '" + data.getUserType()+ "',date  = '" + data.getDate()+ "',email  = '" + data.getEmail()+ "',phone  = '" + data.getPhone()+ "' WHERE userId = '" + data.getUserId()+ "'");
	}

	public void Delete(User data) throws Exception {
		con.getConnection();
		con.aud("DELETE FROM user WHERE userId = '" + data.getUserId()+ "'");
	}

	public List<User> SearchAll() throws Exception {
		List<User> objList = new ArrayList<User>();
		con.getConnection();
		ResultSet rset = con.srh("SELECT * FROM user");
		while(rset.next()){
			User obj = new User();
			obj.setUserId(rset.getInt(1));
			obj.setFullName(rset.getString(2));
			obj.setUsername(rset.getString(3));
			obj.setPassword(rset.getString(4));
			obj.setUserType(rset.getString(5));
			obj.setDate(rset.getString(6));
			obj.setEmail(rset.getString(7));
			obj.setPhone(rset.getString(8));
			objList.add(obj);
		}

	return objList;
	}

	public List<User> Search(User data) throws Exception {
		List<User> objList = new ArrayList<User>();
		con.getConnection();
		ResultSet rset = con.srh("SELECT * FROM user WHERE userId'" + data.getUserId()+ "'");
		while(rset.next()){
			User obj = new User();
			obj.setUserId(rset.getInt(1));
			obj.setFullName(rset.getString(2));
			obj.setUsername(rset.getString(3));
			obj.setPassword(rset.getString(4));
			obj.setUserType(rset.getString(5));
			obj.setDate(rset.getString(6));
			obj.setEmail(rset.getString(7));
			obj.setPhone(rset.getString(8));
			objList.add(obj);
		}

	return objList;
	}

}