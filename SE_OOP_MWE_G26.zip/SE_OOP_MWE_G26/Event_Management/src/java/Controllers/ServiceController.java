//Author     : Shehara P.G.J. IT19141770
package Controllers;


import Models.Service;
import DataBaseConnector.Connector;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class ServiceController{

	Connector con = Connector.getInstance();

	private ServiceController(){
	}

	private static final ServiceController obj = new ServiceController();

	public static ServiceController getInstance(){
		return obj;
	}

	public void Save(Service data) throws Exception {
		con.getConnection();
		con.aud("INSERT INTO service(event_id,service_type,date,duration,supplier_name,supplier_phone_no,supplier_email) values ('" + data.getEvent_id()+ "','" + data.getService_type()+ "','" + data.getDate()+ "','" + data.getDuration()+ "','" + data.getSupplier_name()+ "','" + data.getSupplier_phone_no()+ "','" + data.getSupplier_email()+ "') " );
	}

	public void Update(Service data) throws Exception {
		con.getConnection();
		con.aud("UPDATE service SET event_id  = '" + data.getEvent_id()+ "',service_type  = '" + data.getService_type()+ "',date  = '" + data.getDate()+ "',duration  = '" + data.getDuration()+ "',supplier_name  = '" + data.getSupplier_name()+ "',supplier_phone_no  = '" + data.getSupplier_phone_no()+ "',supplier_email  = '" + data.getSupplier_email()+ "' WHERE service_id = '" + data.getService_id()+ "'");
	}

	public void Delete(Service data) throws Exception {
		con.getConnection();
		con.aud("DELETE FROM service WHERE service_id = '" + data.getService_id()+ "'");
	}

	public List<Service> SearchAll() throws Exception {
		List<Service> objList = new ArrayList<Service>();
		con.getConnection();
		ResultSet rset = con.srh("SELECT * FROM service");
		while(rset.next()){
			Service obj = new Service();
			obj.setService_id(rset.getInt(1));
			obj.setEvent_id(rset.getInt(2));
			obj.setService_type(rset.getString(3));
			obj.setDate(rset.getString(4));
			obj.setDuration(rset.getString(5));
			obj.setSupplier_name(rset.getString(6));
			obj.setSupplier_phone_no(rset.getString(7));
			obj.setSupplier_email(rset.getString(8));
			objList.add(obj);
		}

	return objList;
	}

	public List<Service> Search(Service data) throws Exception {
		List<Service> objList = new ArrayList<Service>();
		con.getConnection();
		ResultSet rset = con.srh("SELECT * FROM service WHERE service_id'" + data.getService_id()+ "'");
		while(rset.next()){
			Service obj = new Service();
			obj.setService_id(rset.getInt(1));
			obj.setEvent_id(rset.getInt(2));
			obj.setService_type(rset.getString(3));
			obj.setDate(rset.getString(4));
			obj.setDuration(rset.getString(5));
			obj.setSupplier_name(rset.getString(6));
			obj.setSupplier_phone_no(rset.getString(7));
			obj.setSupplier_email(rset.getString(8));
			objList.add(obj);
		}

	return objList;
	}

}