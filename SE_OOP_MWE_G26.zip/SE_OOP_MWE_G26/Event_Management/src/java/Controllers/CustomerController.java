//Author     : Vidanage D.K. IT19213286
package Controllers;


import Models.Customer;
import DataBaseConnector.Connector;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class CustomerController{

	Connector con = Connector.getInstance();

	private CustomerController(){
	}

	private static final CustomerController obj = new CustomerController();

	public static CustomerController getInstance(){
		return obj;
	}

	public void Save(Customer data) throws Exception {
		con.getConnection();
		con.aud("INSERT INTO customer(nic,name,email,address,phone,date_of_birth,gender) values ('" + data.getNic()+ "','" + data.getName()+ "','" + data.getEmail()+ "','" + data.getAddress()+ "','" + data.getPhone()+ "','" + data.getDate_of_birth()+ "','" + data.getGender()+ "') " );
	}

	public void Update(Customer data) throws Exception {
		con.getConnection();
		con.aud("UPDATE customer SET nic  = '" + data.getNic()+ "',name  = '" + data.getName()+ "',email  = '" + data.getEmail()+ "',address  = '" + data.getAddress()+ "',phone  = '" + data.getPhone()+ "',date_of_birth  = '" + data.getDate_of_birth()+ "',gender  = '" + data.getGender()+ "' WHERE id = '" + data.getId()+ "'");
	}

	public void Delete(Customer data) throws Exception {
		con.getConnection();
		con.aud("DELETE FROM customer WHERE id = '" + data.getId()+ "'");
	}

	public List<Customer> SearchAll() throws Exception {
		List<Customer> objList = new ArrayList<Customer>();
		con.getConnection();
		ResultSet rset = con.srh("SELECT * FROM customer");
		while(rset.next()){
			Customer obj = new Customer();
			obj.setId(rset.getInt(1));
			obj.setNic(rset.getString(2));
			obj.setName(rset.getString(3));
			obj.setEmail(rset.getString(4));
			obj.setAddress(rset.getString(5));
			obj.setPhone(rset.getString(6));
			obj.setDate_of_birth(rset.getString(7));
			obj.setGender(rset.getString(8));
			objList.add(obj);
		}

	return objList;
	}

	public List<Customer> Search(Customer data) throws Exception {
		List<Customer> objList = new ArrayList<Customer>();
		con.getConnection();
		ResultSet rset = con.srh("SELECT * FROM customer WHERE id'" + data.getId()+ "'");
		while(rset.next()){
			Customer obj = new Customer();
			obj.setId(rset.getInt(1));
			obj.setNic(rset.getString(2));
			obj.setName(rset.getString(3));
			obj.setEmail(rset.getString(4));
			obj.setAddress(rset.getString(5));
			obj.setPhone(rset.getString(6));
			obj.setDate_of_birth(rset.getString(7));
			obj.setGender(rset.getString(8));
			objList.add(obj);
		}

	return objList;
	}

}