//Author     : Hemachandra M.G.S.P. IT19011844
package Controllers;


import Models.Event;
import DataBaseConnector.Connector;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class EventController{

	Connector con = Connector.getInstance();

	private EventController(){
	}

	private static final EventController obj = new EventController();

	public static EventController getInstance(){
		return obj;
	}

	public void Save(Event data) throws Exception {
		con.getConnection();
		con.aud("INSERT INTO event(eventName,eventTheme,packages,date,time,venue) values ('" + data.getEventName()+ "','" + data.getEventTheme()+ "','" + data.getPackages()+ "','" + data.getDate()+ "','" + data.getTime()+ "','" + data.getVenue()+ "') " );
	}

	public void Update(Event data) throws Exception {
		con.getConnection();
		con.aud("UPDATE event SET eventName  = '" + data.getEventName()+ "',eventTheme  = '" + data.getEventTheme()+ "',packages  = '" + data.getPackages()+ "',date  = '" + data.getDate()+ "',time  = '" + data.getTime()+ "',venue  = '" + data.getVenue()+ "' WHERE eventId = '" + data.getEventId()+ "'");
	}

	public void Delete(Event data) throws Exception {
		con.getConnection();
		con.aud("DELETE FROM event WHERE eventId = '" + data.getEventId()+ "'");
	}

	public List<Event> SearchAll() throws Exception {
		List<Event> objList = new ArrayList<Event>();
		con.getConnection();
		ResultSet rset = con.srh("SELECT * FROM event");
		while(rset.next()){
			Event obj = new Event();
			obj.setEventId(rset.getInt(1));
			obj.setEventName(rset.getString(2));
			obj.setEventTheme(rset.getString(3));
			obj.setPackages(rset.getString(4));
			obj.setDate(rset.getString(5));
			obj.setTime(rset.getString(6));
			obj.setVenue(rset.getString(7));
			objList.add(obj);
		}

	return objList;
	}

	public List<Event> Search(Event data) throws Exception {
		List<Event> objList = new ArrayList<Event>();
		con.getConnection();
		ResultSet rset = con.srh("SELECT * FROM event WHERE eventId'" + data.getEventId()+ "'");
		while(rset.next()){
			Event obj = new Event();
			obj.setEventId(rset.getInt(1));
			obj.setEventName(rset.getString(2));
			obj.setEventTheme(rset.getString(3));
			obj.setPackages(rset.getString(4));
			obj.setDate(rset.getString(5));
			obj.setTime(rset.getString(6));
			obj.setVenue(rset.getString(7));
			objList.add(obj);
		}

	return objList;
	}

}