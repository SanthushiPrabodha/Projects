//Author     : Panditha D.T. IT19227528
package Controllers;

import DataBaseConnector.Connector;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class LoginController {

    private LoginController() {
    }

    private static final LoginController obj = new LoginController();

    public static LoginController getInstance() {
        return obj;
    }

    Connector con = Connector.getInstance();

    public List<String> validLogin(String username, String password) throws Exception {
        List<String> user = new ArrayList<String>();
        String uname = "";
        String pass = "";
        con.getConnection();
        ResultSet rs = con.srh("SELECT fullName, userType FROM user WHERE username = '" + username + "' AND password = '" + password + "'");
        while (rs.next()) {
            uname = rs.getString(1);
            pass = rs.getString(2);
        }
        
        user.add(uname);
        user.add(pass);
        return user;
    }
}
