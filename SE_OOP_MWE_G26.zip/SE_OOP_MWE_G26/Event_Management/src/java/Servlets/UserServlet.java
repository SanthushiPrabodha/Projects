//Author     : Panditha D.T. IT19227528
package Servlets;


import Models.User;
import Controllers.UserController;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "UserServlet", urlPatterns = {"/UserServlet"})


public class UserServlet extends HttpServlet {

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {

		String action = request.getParameter("action");
		String pattern = "yyyy/MM/dd - HH:mm:ss";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String current_date = simpleDateFormat.format(new Date());

		if (action.equals("insert")) {
			String fullName = request.getParameter("fullName");
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String userType = request.getParameter("userType");
			String date = request.getParameter("date");
			String email = request.getParameter("email");
			String phone = request.getParameter("phone");
			User obj = new User();
			obj.setFullName(fullName);
			obj.setUsername(username);
			obj.setPassword(password);
			obj.setUserType(userType);
			obj.setDate(date);
			obj.setEmail(email);
			obj.setPhone(phone);
			try {
				UserController.getInstance().Save(obj);
				response.getWriter().println("Saved!");
			} catch (Exception ex) {
				//error
			}
		} else if (action.equals("update")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			String fullName = request.getParameter("fullName");
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String userType = request.getParameter("userType");
			String date = request.getParameter("date");
			String email = request.getParameter("email");
			String phone = request.getParameter("phone");
			User obj = new User();
			obj.setUserId(userId);
			obj.setFullName(fullName);
			obj.setUsername(username);
			obj.setPassword(password);
			obj.setUserType(userType);
			obj.setDate(date);
			obj.setEmail(email);
			obj.setPhone(phone);
			try {
				UserController.getInstance().Update(obj);
				response.getWriter().println("Updated!");
			} catch (Exception ex) {
				//error
			}

		} else if (action.equals("delete")) {
			int userId = Integer.parseInt(request.getParameter("userId"));
			User obj = new User();
			obj.setUserId(userId);
			try {
				UserController.getInstance().Delete(obj);
				response.getWriter().println("Updated!");
			} catch (Exception ex) {
				//error
			}
		} else if (action.equals("serch")) {
			try {
				List<User> list = new ArrayList<>();
				List stringList = new ArrayList<>();

				list = UserController.getInstance().SearchAll();
				for (int i = 0; i < list.size(); i++) {
					String s = list.get(i).getUserId() + "_"+list.get(i).getFullName() + "_"+list.get(i).getUsername() + "_"+list.get(i).getPassword() + "_"+list.get(i).getUserType() + "_"+list.get(i).getDate() + "_"+list.get(i).getEmail() + "_"+list.get(i).getPhone() + "_";
					stringList.add(s);
				}
			String b = String.join("~", stringList);
			response.getWriter().println(b);
			} catch (Exception ex) {
				//Error
			}

		}
		}
	}

@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		processRequest(request, response);
}

@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		processRequest(request, response);
}

@Override
public String getServletInfo() {
	return "Short description";
}
}