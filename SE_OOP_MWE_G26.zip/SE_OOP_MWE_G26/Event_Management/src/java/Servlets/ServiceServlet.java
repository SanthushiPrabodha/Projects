//Author     : Shehara P.G.J. IT19141770
package Servlets;


import Models.Service;
import Controllers.ServiceController;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "ServiceServlet", urlPatterns = {"/ServiceServlet"})


public class ServiceServlet extends HttpServlet {

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {

		String action = request.getParameter("action");
		String pattern = "yyyy/MM/dd - HH:mm:ss";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String current_date = simpleDateFormat.format(new Date());

		if (action.equals("insert")) {
			int event_id = Integer.parseInt(request.getParameter("event_id"));
			String service_type = request.getParameter("service_type");
			String date = request.getParameter("date");
			String duration = request.getParameter("duration");
			String supplier_name = request.getParameter("supplier_name");
			String supplier_phone_no = request.getParameter("supplier_phone_no");
			String supplier_email = request.getParameter("supplier_email");
			Service obj = new Service();
			obj.setEvent_id(event_id);
			obj.setService_type(service_type);
			obj.setDate(date);
			obj.setDuration(duration);
			obj.setSupplier_name(supplier_name);
			obj.setSupplier_phone_no(supplier_phone_no);
			obj.setSupplier_email(supplier_email);
			try {
				ServiceController.getInstance().Save(obj);
				response.getWriter().println("Saved!");
			} catch (Exception ex) {
				//error
			}
		} else if (action.equals("update")) {
			int service_id = Integer.parseInt(request.getParameter("service_id"));
			int event_id = Integer.parseInt(request.getParameter("event_id"));
			String service_type = request.getParameter("service_type");
			String date = request.getParameter("date");
			String duration = request.getParameter("duration");
			String supplier_name = request.getParameter("supplier_name");
			String supplier_phone_no = request.getParameter("supplier_phone_no");
			String supplier_email = request.getParameter("supplier_email");
			Service obj = new Service();
			obj.setService_id(service_id);
			obj.setEvent_id(event_id);
			obj.setService_type(service_type);
			obj.setDate(date);
			obj.setDuration(duration);
			obj.setSupplier_name(supplier_name);
			obj.setSupplier_phone_no(supplier_phone_no);
			obj.setSupplier_email(supplier_email);
			try {
				ServiceController.getInstance().Update(obj);
				response.getWriter().println("Updated!");
			} catch (Exception ex) {
				//error
			}

		} else if (action.equals("delete")) {
			int service_id = Integer.parseInt(request.getParameter("service_id"));
			Service obj = new Service();
			obj.setService_id(service_id);
			try {
				ServiceController.getInstance().Delete(obj);
				response.getWriter().println("Updated!");
			} catch (Exception ex) {
				//error
			}
		} else if (action.equals("serch")) {
			try {
				List<Service> list = new ArrayList<>();
				List stringList = new ArrayList<>();

				list = ServiceController.getInstance().SearchAll();
				for (int i = 0; i < list.size(); i++) {
					String s = list.get(i).getService_id() + "_"+list.get(i).getEvent_id() + "_"+list.get(i).getService_type() + "_"+list.get(i).getDate() + "_"+list.get(i).getDuration() + "_"+list.get(i).getSupplier_name() + "_"+list.get(i).getSupplier_phone_no() + "_"+list.get(i).getSupplier_email() + "_";
					stringList.add(s);
				}
			String b = String.join("~", stringList);
			response.getWriter().println(b);
			} catch (Exception ex) {
				//Error
			}

		}
		}
	}

@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		processRequest(request, response);
}

@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		processRequest(request, response);
}

@Override
public String getServletInfo() {
	return "Short description";
}
}